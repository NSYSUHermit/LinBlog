
# Import Data & Standard Scaler


```python
import pandas as pd
import numpy as np
from sklearn import datasets
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

#d = pd.read_csv('C:/Users/User/OneDrive - student.nsysu.edu.tw/Documents/dataset/creditcard.csv')
df = datasets.load_breast_cancer()
x = pd.DataFrame(df['data'],columns = df['feature_names'])[0:100]

x = pd.DataFrame(StandardScaler().fit_transform(x))

y = pd.DataFrame(df['target'],columns = ['targets_names'])[0:100]
d = pd.concat([x,y],axis = 1)

#show the data of labels
%matplotlib inline
by_fraud = y.groupby('targets_names')
by_fraud.size().plot(kind = 'bar')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1d953959c88>




![png](output_1_1.png)



```python
import pandas as pd
import numpy as np
import pickle
import matplotlib.pyplot as plt
plt.style.use('seaborn')
import tensorflow as tf
import seaborn as sns
from sklearn.model_selection import train_test_split
from keras.models import Model, load_model
from keras.layers import Input, Dense
from keras.callbacks import ModelCheckpoint
from keras import regularizers
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_curve, auc, precision_recall_curve
```


```python
# 查看樣本比例
num_nonfraud = np.sum(d['targets_names'] == 0)
num_fraud = np.sum(d['targets_names'] == 1)
plt.bar(['Positive', 'Negative'], [num_fraud, num_nonfraud], color='dodgerblue')
plt.show()
data = d
# 刪除時間列，對Amount進行標準化
#data = d.drop(['Time'], axis=1)
#data['Amount'] = StandardScaler().fit_transform(data[['Amount']])

# 提取負樣本，並且按照1:1切成訓練集和測試集
mask = (data['targets_names'] == 0)
X_train, X_test = train_test_split(data[mask], test_size=0.5, random_state=920)
X_train = X_train.drop(['targets_names'], axis=1).values
X_test = X_test.drop(['targets_names'], axis=1).values

# 提取所有正樣本，作為測試集的一部分
X_fraud = data[~mask].drop(['targets_names'], axis=1).values

# 設置Autoencoder的參數
# 隱藏層節點數分別為16，8，8，16
# epoch為50，batch size為32
input_dim = X_train.shape[1]
encoding_dim = 16
num_epoch = 250
batch_size = 32

input_layer = Input(shape=(input_dim, ))
encoder = Dense(encoding_dim, activation="tanh",
                activity_regularizer=regularizers.l1(10e-5))(input_layer)
encoder = Dense(int(encoding_dim / 2), activation="relu")(encoder)
decoder = Dense(int(encoding_dim / 2), activation='tanh')(encoder)
decoder = Dense(input_dim, activation='relu')(decoder)
autoencoder = Model(inputs=input_layer, outputs=decoder)
autoencoder.compile(optimizer='adam',loss='mean_squared_error',metrics=['mae'])

# 模型保存為hermit_model，並開始訓練模型
checkpointer = ModelCheckpoint(filepath="hermit_model",verbose=0,save_best_only=True)
history = autoencoder.fit(X_train, X_train,
                          epochs=num_epoch,
                          batch_size=batch_size,
                          shuffle=True,
                          validation_data=(X_test, X_test),
                          verbose=1, 
                          callbacks=[checkpointer]).history

# 畫出損失函數曲線
plt.figure(figsize=(14, 5))
plt.subplot(121)
plt.plot(history['loss'], c='dodgerblue', lw=3)
plt.plot(history['val_loss'], c='coral', lw=3)
plt.title('model loss')
plt.ylabel('mse'); plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper right')

plt.subplot(122)
plt.plot(history['mean_absolute_error'], c='dodgerblue', lw=3)
plt.plot(history['val_mean_absolute_error'], c='coral', lw=3)
plt.title('model mae')
plt.ylabel('mae'); plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper right');
```


![png](output_3_0.png)


    Train on 32 samples, validate on 33 samples
    Epoch 1/250
    32/32 [==============================] - 1s 41ms/step - loss: 1.1633 - mean_absolute_error: 0.7738 - val_loss: 0.7262 - val_mean_absolute_error: 0.6667
    Epoch 2/250
    32/32 [==============================] - 0s 93us/step - loss: 1.1595 - mean_absolute_error: 0.7725 - val_loss: 0.7242 - val_mean_absolute_error: 0.6658
    Epoch 3/250
    32/32 [==============================] - 0s 93us/step - loss: 1.1550 - mean_absolute_error: 0.7709 - val_loss: 0.7222 - val_mean_absolute_error: 0.6649
    Epoch 4/250
    32/32 [==============================] - 0s 62us/step - loss: 1.1502 - mean_absolute_error: 0.7692 - val_loss: 0.7201 - val_mean_absolute_error: 0.6639
    Epoch 5/250
    32/32 [==============================] - 0s 94us/step - loss: 1.1453 - mean_absolute_error: 0.7674 - val_loss: 0.7179 - val_mean_absolute_error: 0.6629
    Epoch 6/250
    32/32 [==============================] - 0s 93us/step - loss: 1.1402 - mean_absolute_error: 0.7657 - val_loss: 0.7155 - val_mean_absolute_error: 0.6619
    Epoch 7/250
    32/32 [==============================] - 0s 95us/step - loss: 1.1352 - mean_absolute_error: 0.7639 - val_loss: 0.7131 - val_mean_absolute_error: 0.6608
    Epoch 8/250
    32/32 [==============================] - 0s 94us/step - loss: 1.1303 - mean_absolute_error: 0.7622 - val_loss: 0.7107 - val_mean_absolute_error: 0.6597
    Epoch 9/250
    32/32 [==============================] - 0s 94us/step - loss: 1.1254 - mean_absolute_error: 0.7605 - val_loss: 0.7083 - val_mean_absolute_error: 0.6586
    Epoch 10/250
    32/32 [==============================] - 0s 94us/step - loss: 1.1203 - mean_absolute_error: 0.7588 - val_loss: 0.7061 - val_mean_absolute_error: 0.6576
    Epoch 11/250
    32/32 [==============================] - 0s 93us/step - loss: 1.1150 - mean_absolute_error: 0.7570 - val_loss: 0.7038 - val_mean_absolute_error: 0.6565
    Epoch 12/250
    32/32 [==============================] - 0s 93us/step - loss: 1.1095 - mean_absolute_error: 0.7552 - val_loss: 0.7013 - val_mean_absolute_error: 0.6554
    Epoch 13/250
    32/32 [==============================] - 0s 94us/step - loss: 1.1039 - mean_absolute_error: 0.7534 - val_loss: 0.6988 - val_mean_absolute_error: 0.6542
    Epoch 14/250
    32/32 [==============================] - 0s 125us/step - loss: 1.0982 - mean_absolute_error: 0.7516 - val_loss: 0.6961 - val_mean_absolute_error: 0.6530
    Epoch 15/250
    32/32 [==============================] - 0s 94us/step - loss: 1.0925 - mean_absolute_error: 0.7497 - val_loss: 0.6933 - val_mean_absolute_error: 0.6517
    Epoch 16/250
    32/32 [==============================] - 0s 93us/step - loss: 1.0868 - mean_absolute_error: 0.7479 - val_loss: 0.6904 - val_mean_absolute_error: 0.6504
    Epoch 17/250
    32/32 [==============================] - 0s 94us/step - loss: 1.0809 - mean_absolute_error: 0.7459 - val_loss: 0.6875 - val_mean_absolute_error: 0.6491
    Epoch 18/250
    32/32 [==============================] - 0s 94us/step - loss: 1.0748 - mean_absolute_error: 0.7439 - val_loss: 0.6845 - val_mean_absolute_error: 0.6478
    Epoch 19/250
    32/32 [==============================] - 0s 93us/step - loss: 1.0687 - mean_absolute_error: 0.7419 - val_loss: 0.6817 - val_mean_absolute_error: 0.6465
    Epoch 20/250
    32/32 [==============================] - 0s 125us/step - loss: 1.0624 - mean_absolute_error: 0.7402 - val_loss: 0.6789 - val_mean_absolute_error: 0.6454
    Epoch 21/250
    32/32 [==============================] - 0s 62us/step - loss: 1.0563 - mean_absolute_error: 0.7384 - val_loss: 0.6762 - val_mean_absolute_error: 0.6442
    Epoch 22/250
    32/32 [==============================] - 0s 62us/step - loss: 1.0504 - mean_absolute_error: 0.7367 - val_loss: 0.6735 - val_mean_absolute_error: 0.6431
    Epoch 23/250
    32/32 [==============================] - 0s 94us/step - loss: 1.0445 - mean_absolute_error: 0.7350 - val_loss: 0.6710 - val_mean_absolute_error: 0.6421
    Epoch 24/250
    32/32 [==============================] - 0s 62us/step - loss: 1.0387 - mean_absolute_error: 0.7332 - val_loss: 0.6685 - val_mean_absolute_error: 0.6410
    Epoch 25/250
    32/32 [==============================] - 0s 94us/step - loss: 1.0328 - mean_absolute_error: 0.7314 - val_loss: 0.6661 - val_mean_absolute_error: 0.6399
    Epoch 26/250
    32/32 [==============================] - 0s 94us/step - loss: 1.0271 - mean_absolute_error: 0.7297 - val_loss: 0.6637 - val_mean_absolute_error: 0.6388
    Epoch 27/250
    32/32 [==============================] - 0s 94us/step - loss: 1.0216 - mean_absolute_error: 0.7279 - val_loss: 0.6613 - val_mean_absolute_error: 0.6376
    Epoch 28/250
    32/32 [==============================] - 0s 125us/step - loss: 1.0161 - mean_absolute_error: 0.7262 - val_loss: 0.6591 - val_mean_absolute_error: 0.6365
    Epoch 29/250
    32/32 [==============================] - 0s 94us/step - loss: 1.0108 - mean_absolute_error: 0.7244 - val_loss: 0.6568 - val_mean_absolute_error: 0.6354
    Epoch 30/250
    32/32 [==============================] - 0s 94us/step - loss: 1.0057 - mean_absolute_error: 0.7227 - val_loss: 0.6546 - val_mean_absolute_error: 0.6343
    Epoch 31/250
    32/32 [==============================] - 0s 94us/step - loss: 1.0006 - mean_absolute_error: 0.7210 - val_loss: 0.6525 - val_mean_absolute_error: 0.6331
    Epoch 32/250
    32/32 [==============================] - 0s 93us/step - loss: 0.9955 - mean_absolute_error: 0.7194 - val_loss: 0.6504 - val_mean_absolute_error: 0.6320
    Epoch 33/250
    32/32 [==============================] - 0s 93us/step - loss: 0.9906 - mean_absolute_error: 0.7179 - val_loss: 0.6483 - val_mean_absolute_error: 0.6310
    Epoch 34/250
    32/32 [==============================] - 0s 124us/step - loss: 0.9858 - mean_absolute_error: 0.7164 - val_loss: 0.6463 - val_mean_absolute_error: 0.6299
    Epoch 35/250
    32/32 [==============================] - 0s 93us/step - loss: 0.9813 - mean_absolute_error: 0.7149 - val_loss: 0.6444 - val_mean_absolute_error: 0.6289
    Epoch 36/250
    32/32 [==============================] - 0s 94us/step - loss: 0.9769 - mean_absolute_error: 0.7136 - val_loss: 0.6424 - val_mean_absolute_error: 0.6279
    Epoch 37/250
    32/32 [==============================] - 0s 93us/step - loss: 0.9726 - mean_absolute_error: 0.7122 - val_loss: 0.6405 - val_mean_absolute_error: 0.6268
    Epoch 38/250
    32/32 [==============================] - 0s 93us/step - loss: 0.9684 - mean_absolute_error: 0.7109 - val_loss: 0.6386 - val_mean_absolute_error: 0.6258
    Epoch 39/250
    32/32 [==============================] - 0s 93us/step - loss: 0.9643 - mean_absolute_error: 0.7095 - val_loss: 0.6368 - val_mean_absolute_error: 0.6247
    Epoch 40/250
    32/32 [==============================] - 0s 94us/step - loss: 0.9602 - mean_absolute_error: 0.7082 - val_loss: 0.6350 - val_mean_absolute_error: 0.6237
    Epoch 41/250
    32/32 [==============================] - 0s 94us/step - loss: 0.9561 - mean_absolute_error: 0.7068 - val_loss: 0.6333 - val_mean_absolute_error: 0.6226
    Epoch 42/250
    32/32 [==============================] - 0s 93us/step - loss: 0.9521 - mean_absolute_error: 0.7054 - val_loss: 0.6315 - val_mean_absolute_error: 0.6216
    Epoch 43/250
    32/32 [==============================] - 0s 94us/step - loss: 0.9482 - mean_absolute_error: 0.7041 - val_loss: 0.6297 - val_mean_absolute_error: 0.6206
    Epoch 44/250
    32/32 [==============================] - 0s 94us/step - loss: 0.9444 - mean_absolute_error: 0.7028 - val_loss: 0.6280 - val_mean_absolute_error: 0.6196
    Epoch 45/250
    32/32 [==============================] - 0s 94us/step - loss: 0.9405 - mean_absolute_error: 0.7015 - val_loss: 0.6263 - val_mean_absolute_error: 0.6187
    Epoch 46/250
    32/32 [==============================] - 0s 94us/step - loss: 0.9367 - mean_absolute_error: 0.7001 - val_loss: 0.6246 - val_mean_absolute_error: 0.6177
    Epoch 47/250
    32/32 [==============================] - 0s 94us/step - loss: 0.9329 - mean_absolute_error: 0.6988 - val_loss: 0.6229 - val_mean_absolute_error: 0.6168
    Epoch 48/250
    32/32 [==============================] - 0s 93us/step - loss: 0.9291 - mean_absolute_error: 0.6975 - val_loss: 0.6212 - val_mean_absolute_error: 0.6158
    Epoch 49/250
    32/32 [==============================] - 0s 94us/step - loss: 0.9253 - mean_absolute_error: 0.6961 - val_loss: 0.6194 - val_mean_absolute_error: 0.6148
    Epoch 50/250
    32/32 [==============================] - 0s 125us/step - loss: 0.9215 - mean_absolute_error: 0.6948 - val_loss: 0.6176 - val_mean_absolute_error: 0.6138
    Epoch 51/250
    32/32 [==============================] - 0s 125us/step - loss: 0.9178 - mean_absolute_error: 0.6935 - val_loss: 0.6157 - val_mean_absolute_error: 0.6128
    Epoch 52/250
    32/32 [==============================] - 0s 93us/step - loss: 0.9141 - mean_absolute_error: 0.6921 - val_loss: 0.6137 - val_mean_absolute_error: 0.6117
    Epoch 53/250
    32/32 [==============================] - 0s 93us/step - loss: 0.9105 - mean_absolute_error: 0.6908 - val_loss: 0.6118 - val_mean_absolute_error: 0.6106
    Epoch 54/250
    32/32 [==============================] - 0s 156us/step - loss: 0.9068 - mean_absolute_error: 0.6895 - val_loss: 0.6098 - val_mean_absolute_error: 0.6096
    Epoch 55/250
    32/32 [==============================] - 0s 93us/step - loss: 0.9032 - mean_absolute_error: 0.6882 - val_loss: 0.6079 - val_mean_absolute_error: 0.6085
    Epoch 56/250
    32/32 [==============================] - 0s 93us/step - loss: 0.8996 - mean_absolute_error: 0.6868 - val_loss: 0.6060 - val_mean_absolute_error: 0.6075
    Epoch 57/250
    32/32 [==============================] - 0s 125us/step - loss: 0.8961 - mean_absolute_error: 0.6855 - val_loss: 0.6041 - val_mean_absolute_error: 0.6065
    Epoch 58/250
    32/32 [==============================] - 0s 94us/step - loss: 0.8926 - mean_absolute_error: 0.6842 - val_loss: 0.6022 - val_mean_absolute_error: 0.6054
    Epoch 59/250
    32/32 [==============================] - 0s 94us/step - loss: 0.8891 - mean_absolute_error: 0.6828 - val_loss: 0.6002 - val_mean_absolute_error: 0.6044
    Epoch 60/250
    32/32 [==============================] - 0s 94us/step - loss: 0.8857 - mean_absolute_error: 0.6815 - val_loss: 0.5982 - val_mean_absolute_error: 0.6033
    Epoch 61/250
    32/32 [==============================] - 0s 94us/step - loss: 0.8822 - mean_absolute_error: 0.6801 - val_loss: 0.5962 - val_mean_absolute_error: 0.6022
    Epoch 62/250
    32/32 [==============================] - 0s 93us/step - loss: 0.8788 - mean_absolute_error: 0.6787 - val_loss: 0.5941 - val_mean_absolute_error: 0.6011
    Epoch 63/250
    32/32 [==============================] - 0s 124us/step - loss: 0.8755 - mean_absolute_error: 0.6774 - val_loss: 0.5920 - val_mean_absolute_error: 0.6000
    Epoch 64/250
    32/32 [==============================] - 0s 63us/step - loss: 0.8722 - mean_absolute_error: 0.6760 - val_loss: 0.5899 - val_mean_absolute_error: 0.5990
    Epoch 65/250
    32/32 [==============================] - 0s 94us/step - loss: 0.8689 - mean_absolute_error: 0.6747 - val_loss: 0.5878 - val_mean_absolute_error: 0.5979
    Epoch 66/250
    32/32 [==============================] - 0s 124us/step - loss: 0.8657 - mean_absolute_error: 0.6733 - val_loss: 0.5858 - val_mean_absolute_error: 0.5969
    Epoch 67/250
    32/32 [==============================] - 0s 94us/step - loss: 0.8624 - mean_absolute_error: 0.6719 - val_loss: 0.5838 - val_mean_absolute_error: 0.5959
    Epoch 68/250
    32/32 [==============================] - 0s 94us/step - loss: 0.8591 - mean_absolute_error: 0.6705 - val_loss: 0.5818 - val_mean_absolute_error: 0.5948
    Epoch 69/250
    32/32 [==============================] - 0s 93us/step - loss: 0.8559 - mean_absolute_error: 0.6692 - val_loss: 0.5798 - val_mean_absolute_error: 0.5938
    Epoch 70/250
    32/32 [==============================] - 0s 93us/step - loss: 0.8527 - mean_absolute_error: 0.6679 - val_loss: 0.5778 - val_mean_absolute_error: 0.5928
    Epoch 71/250
    32/32 [==============================] - 0s 62us/step - loss: 0.8496 - mean_absolute_error: 0.6666 - val_loss: 0.5759 - val_mean_absolute_error: 0.5917
    Epoch 72/250
    32/32 [==============================] - 0s 125us/step - loss: 0.8465 - mean_absolute_error: 0.6653 - val_loss: 0.5740 - val_mean_absolute_error: 0.5907
    Epoch 73/250
    32/32 [==============================] - 0s 94us/step - loss: 0.8434 - mean_absolute_error: 0.6640 - val_loss: 0.5722 - val_mean_absolute_error: 0.5898
    Epoch 74/250
    32/32 [==============================] - 0s 125us/step - loss: 0.8403 - mean_absolute_error: 0.6627 - val_loss: 0.5705 - val_mean_absolute_error: 0.5888
    Epoch 75/250
    32/32 [==============================] - 0s 94us/step - loss: 0.8372 - mean_absolute_error: 0.6614 - val_loss: 0.5687 - val_mean_absolute_error: 0.5879
    Epoch 76/250
    32/32 [==============================] - 0s 125us/step - loss: 0.8341 - mean_absolute_error: 0.6602 - val_loss: 0.5671 - val_mean_absolute_error: 0.5870
    Epoch 77/250
    32/32 [==============================] - 0s 93us/step - loss: 0.8311 - mean_absolute_error: 0.6589 - val_loss: 0.5654 - val_mean_absolute_error: 0.5860
    Epoch 78/250
    32/32 [==============================] - 0s 93us/step - loss: 0.8280 - mean_absolute_error: 0.6577 - val_loss: 0.5638 - val_mean_absolute_error: 0.5852
    Epoch 79/250
    32/32 [==============================] - 0s 93us/step - loss: 0.8250 - mean_absolute_error: 0.6564 - val_loss: 0.5622 - val_mean_absolute_error: 0.5843
    Epoch 80/250
    32/32 [==============================] - 0s 93us/step - loss: 0.8220 - mean_absolute_error: 0.6551 - val_loss: 0.5606 - val_mean_absolute_error: 0.5834
    Epoch 81/250
    32/32 [==============================] - 0s 93us/step - loss: 0.8191 - mean_absolute_error: 0.6539 - val_loss: 0.5591 - val_mean_absolute_error: 0.5826
    Epoch 82/250
    32/32 [==============================] - 0s 93us/step - loss: 0.8161 - mean_absolute_error: 0.6526 - val_loss: 0.5576 - val_mean_absolute_error: 0.5818
    Epoch 83/250
    32/32 [==============================] - 0s 93us/step - loss: 0.8133 - mean_absolute_error: 0.6514 - val_loss: 0.5562 - val_mean_absolute_error: 0.5810
    Epoch 84/250
    32/32 [==============================] - 0s 94us/step - loss: 0.8104 - mean_absolute_error: 0.6502 - val_loss: 0.5548 - val_mean_absolute_error: 0.5802
    Epoch 85/250
    32/32 [==============================] - 0s 94us/step - loss: 0.8076 - mean_absolute_error: 0.6489 - val_loss: 0.5535 - val_mean_absolute_error: 0.5794
    Epoch 86/250
    32/32 [==============================] - 0s 93us/step - loss: 0.8048 - mean_absolute_error: 0.6477 - val_loss: 0.5521 - val_mean_absolute_error: 0.5787
    Epoch 87/250
    32/32 [==============================] - 0s 125us/step - loss: 0.8021 - mean_absolute_error: 0.6465 - val_loss: 0.5508 - val_mean_absolute_error: 0.5780
    Epoch 88/250
    32/32 [==============================] - 0s 94us/step - loss: 0.7994 - mean_absolute_error: 0.6453 - val_loss: 0.5496 - val_mean_absolute_error: 0.5773
    Epoch 89/250
    32/32 [==============================] - 0s 93us/step - loss: 0.7967 - mean_absolute_error: 0.6442 - val_loss: 0.5483 - val_mean_absolute_error: 0.5766
    Epoch 90/250
    32/32 [==============================] - 0s 93us/step - loss: 0.7940 - mean_absolute_error: 0.6430 - val_loss: 0.5471 - val_mean_absolute_error: 0.5760
    Epoch 91/250
    32/32 [==============================] - 0s 94us/step - loss: 0.7914 - mean_absolute_error: 0.6418 - val_loss: 0.5459 - val_mean_absolute_error: 0.5754
    Epoch 92/250
    32/32 [==============================] - 0s 93us/step - loss: 0.7887 - mean_absolute_error: 0.6406 - val_loss: 0.5447 - val_mean_absolute_error: 0.5748
    Epoch 93/250
    32/32 [==============================] - 0s 93us/step - loss: 0.7860 - mean_absolute_error: 0.6394 - val_loss: 0.5435 - val_mean_absolute_error: 0.5742
    Epoch 94/250
    32/32 [==============================] - 0s 94us/step - loss: 0.7834 - mean_absolute_error: 0.6383 - val_loss: 0.5423 - val_mean_absolute_error: 0.5737
    Epoch 95/250
    32/32 [==============================] - 0s 93us/step - loss: 0.7809 - mean_absolute_error: 0.6371 - val_loss: 0.5411 - val_mean_absolute_error: 0.5731
    Epoch 96/250
    32/32 [==============================] - 0s 125us/step - loss: 0.7783 - mean_absolute_error: 0.6360 - val_loss: 0.5400 - val_mean_absolute_error: 0.5725
    Epoch 97/250
    32/32 [==============================] - 0s 125us/step - loss: 0.7758 - mean_absolute_error: 0.6349 - val_loss: 0.5388 - val_mean_absolute_error: 0.5720
    Epoch 98/250
    32/32 [==============================] - 0s 94us/step - loss: 0.7733 - mean_absolute_error: 0.6338 - val_loss: 0.5377 - val_mean_absolute_error: 0.5714
    Epoch 99/250
    32/32 [==============================] - 0s 93us/step - loss: 0.7708 - mean_absolute_error: 0.6327 - val_loss: 0.5367 - val_mean_absolute_error: 0.5708
    Epoch 100/250
    32/32 [==============================] - 0s 94us/step - loss: 0.7683 - mean_absolute_error: 0.6316 - val_loss: 0.5356 - val_mean_absolute_error: 0.5702
    Epoch 101/250
    32/32 [==============================] - 0s 93us/step - loss: 0.7659 - mean_absolute_error: 0.6305 - val_loss: 0.5345 - val_mean_absolute_error: 0.5696
    Epoch 102/250
    32/32 [==============================] - 0s 93us/step - loss: 0.7635 - mean_absolute_error: 0.6294 - val_loss: 0.5334 - val_mean_absolute_error: 0.5690
    Epoch 103/250
    32/32 [==============================] - 0s 125us/step - loss: 0.7611 - mean_absolute_error: 0.6283 - val_loss: 0.5324 - val_mean_absolute_error: 0.5684
    Epoch 104/250
    32/32 [==============================] - 0s 127us/step - loss: 0.7587 - mean_absolute_error: 0.6273 - val_loss: 0.5314 - val_mean_absolute_error: 0.5679
    Epoch 105/250
    32/32 [==============================] - 0s 62us/step - loss: 0.7563 - mean_absolute_error: 0.6262 - val_loss: 0.5304 - val_mean_absolute_error: 0.5673
    Epoch 106/250
    32/32 [==============================] - 0s 94us/step - loss: 0.7540 - mean_absolute_error: 0.6252 - val_loss: 0.5295 - val_mean_absolute_error: 0.5667
    Epoch 107/250
    32/32 [==============================] - 0s 93us/step - loss: 0.7517 - mean_absolute_error: 0.6242 - val_loss: 0.5285 - val_mean_absolute_error: 0.5661
    Epoch 108/250
    32/32 [==============================] - 0s 125us/step - loss: 0.7494 - mean_absolute_error: 0.6231 - val_loss: 0.5276 - val_mean_absolute_error: 0.5656
    Epoch 109/250
    32/32 [==============================] - 0s 94us/step - loss: 0.7472 - mean_absolute_error: 0.6221 - val_loss: 0.5266 - val_mean_absolute_error: 0.5650
    Epoch 110/250
    32/32 [==============================] - 0s 94us/step - loss: 0.7449 - mean_absolute_error: 0.6212 - val_loss: 0.5257 - val_mean_absolute_error: 0.5645
    Epoch 111/250
    32/32 [==============================] - 0s 125us/step - loss: 0.7427 - mean_absolute_error: 0.6202 - val_loss: 0.5248 - val_mean_absolute_error: 0.5639
    Epoch 112/250
    32/32 [==============================] - 0s 94us/step - loss: 0.7405 - mean_absolute_error: 0.6192 - val_loss: 0.5239 - val_mean_absolute_error: 0.5634
    Epoch 113/250
    32/32 [==============================] - 0s 125us/step - loss: 0.7383 - mean_absolute_error: 0.6183 - val_loss: 0.5230 - val_mean_absolute_error: 0.5628
    Epoch 114/250
    32/32 [==============================] - 0s 125us/step - loss: 0.7362 - mean_absolute_error: 0.6173 - val_loss: 0.5221 - val_mean_absolute_error: 0.5623
    Epoch 115/250
    32/32 [==============================] - 0s 93us/step - loss: 0.7341 - mean_absolute_error: 0.6164 - val_loss: 0.5212 - val_mean_absolute_error: 0.5618
    Epoch 116/250
    32/32 [==============================] - 0s 125us/step - loss: 0.7319 - mean_absolute_error: 0.6155 - val_loss: 0.5203 - val_mean_absolute_error: 0.5613
    Epoch 117/250
    32/32 [==============================] - 0s 125us/step - loss: 0.7298 - mean_absolute_error: 0.6145 - val_loss: 0.5195 - val_mean_absolute_error: 0.5607
    Epoch 118/250
    32/32 [==============================] - 0s 94us/step - loss: 0.7278 - mean_absolute_error: 0.6136 - val_loss: 0.5186 - val_mean_absolute_error: 0.5602
    Epoch 119/250
    32/32 [==============================] - 0s 94us/step - loss: 0.7257 - mean_absolute_error: 0.6126 - val_loss: 0.5178 - val_mean_absolute_error: 0.5597
    Epoch 120/250
    32/32 [==============================] - 0s 125us/step - loss: 0.7237 - mean_absolute_error: 0.6117 - val_loss: 0.5169 - val_mean_absolute_error: 0.5591
    Epoch 121/250
    32/32 [==============================] - 0s 94us/step - loss: 0.7217 - mean_absolute_error: 0.6107 - val_loss: 0.5161 - val_mean_absolute_error: 0.5586
    Epoch 122/250
    32/32 [==============================] - 0s 62us/step - loss: 0.7197 - mean_absolute_error: 0.6098 - val_loss: 0.5152 - val_mean_absolute_error: 0.5581
    Epoch 123/250
    32/32 [==============================] - 0s 94us/step - loss: 0.7177 - mean_absolute_error: 0.6089 - val_loss: 0.5144 - val_mean_absolute_error: 0.5575
    Epoch 124/250
    32/32 [==============================] - 0s 94us/step - loss: 0.7157 - mean_absolute_error: 0.6080 - val_loss: 0.5135 - val_mean_absolute_error: 0.5570
    Epoch 125/250
    32/32 [==============================] - 0s 62us/step - loss: 0.7137 - mean_absolute_error: 0.6071 - val_loss: 0.5126 - val_mean_absolute_error: 0.5564
    Epoch 126/250
    32/32 [==============================] - 0s 125us/step - loss: 0.7118 - mean_absolute_error: 0.6062 - val_loss: 0.5118 - val_mean_absolute_error: 0.5559
    Epoch 127/250
    32/32 [==============================] - 0s 93us/step - loss: 0.7098 - mean_absolute_error: 0.6053 - val_loss: 0.5110 - val_mean_absolute_error: 0.5554
    Epoch 128/250
    32/32 [==============================] - 0s 93us/step - loss: 0.7079 - mean_absolute_error: 0.6044 - val_loss: 0.5102 - val_mean_absolute_error: 0.5549
    Epoch 129/250
    32/32 [==============================] - 0s 125us/step - loss: 0.7060 - mean_absolute_error: 0.6035 - val_loss: 0.5094 - val_mean_absolute_error: 0.5544
    Epoch 130/250
    32/32 [==============================] - 0s 125us/step - loss: 0.7041 - mean_absolute_error: 0.6026 - val_loss: 0.5086 - val_mean_absolute_error: 0.5539
    Epoch 131/250
    32/32 [==============================] - 0s 93us/step - loss: 0.7022 - mean_absolute_error: 0.6017 - val_loss: 0.5079 - val_mean_absolute_error: 0.5534
    Epoch 132/250
    32/32 [==============================] - 0s 93us/step - loss: 0.7003 - mean_absolute_error: 0.6008 - val_loss: 0.5071 - val_mean_absolute_error: 0.5528
    Epoch 133/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6984 - mean_absolute_error: 0.5999 - val_loss: 0.5064 - val_mean_absolute_error: 0.5523
    Epoch 134/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6966 - mean_absolute_error: 0.5990 - val_loss: 0.5057 - val_mean_absolute_error: 0.5518
    Epoch 135/250
    32/32 [==============================] - 0s 125us/step - loss: 0.6947 - mean_absolute_error: 0.5981 - val_loss: 0.5049 - val_mean_absolute_error: 0.5513
    Epoch 136/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6929 - mean_absolute_error: 0.5973 - val_loss: 0.5042 - val_mean_absolute_error: 0.5508
    Epoch 137/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6911 - mean_absolute_error: 0.5964 - val_loss: 0.5035 - val_mean_absolute_error: 0.5504
    Epoch 138/250
    32/32 [==============================] - 0s 125us/step - loss: 0.6893 - mean_absolute_error: 0.5955 - val_loss: 0.5028 - val_mean_absolute_error: 0.5499
    Epoch 139/250
    32/32 [==============================] - 0s 125us/step - loss: 0.6875 - mean_absolute_error: 0.5947 - val_loss: 0.5021 - val_mean_absolute_error: 0.5494
    Epoch 140/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6857 - mean_absolute_error: 0.5938 - val_loss: 0.5014 - val_mean_absolute_error: 0.5489
    Epoch 141/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6839 - mean_absolute_error: 0.5929 - val_loss: 0.5007 - val_mean_absolute_error: 0.5485
    Epoch 142/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6822 - mean_absolute_error: 0.5921 - val_loss: 0.5000 - val_mean_absolute_error: 0.5480
    Epoch 143/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6805 - mean_absolute_error: 0.5913 - val_loss: 0.4994 - val_mean_absolute_error: 0.5475
    Epoch 144/250
    32/32 [==============================] - 0s 125us/step - loss: 0.6787 - mean_absolute_error: 0.5904 - val_loss: 0.4987 - val_mean_absolute_error: 0.5471
    Epoch 145/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6771 - mean_absolute_error: 0.5896 - val_loss: 0.4980 - val_mean_absolute_error: 0.5466
    Epoch 146/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6754 - mean_absolute_error: 0.5887 - val_loss: 0.4974 - val_mean_absolute_error: 0.5462
    Epoch 147/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6737 - mean_absolute_error: 0.5879 - val_loss: 0.4967 - val_mean_absolute_error: 0.5457
    Epoch 148/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6721 - mean_absolute_error: 0.5871 - val_loss: 0.4960 - val_mean_absolute_error: 0.5453
    Epoch 149/250
    32/32 [==============================] - 0s 125us/step - loss: 0.6704 - mean_absolute_error: 0.5863 - val_loss: 0.4954 - val_mean_absolute_error: 0.5448
    Epoch 150/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6688 - mean_absolute_error: 0.5855 - val_loss: 0.4948 - val_mean_absolute_error: 0.5444
    Epoch 151/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6672 - mean_absolute_error: 0.5847 - val_loss: 0.4942 - val_mean_absolute_error: 0.5440
    Epoch 152/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6656 - mean_absolute_error: 0.5839 - val_loss: 0.4937 - val_mean_absolute_error: 0.5436
    Epoch 153/250
    32/32 [==============================] - 0s 125us/step - loss: 0.6640 - mean_absolute_error: 0.5831 - val_loss: 0.4931 - val_mean_absolute_error: 0.5432
    Epoch 154/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6625 - mean_absolute_error: 0.5823 - val_loss: 0.4926 - val_mean_absolute_error: 0.5429
    Epoch 155/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6609 - mean_absolute_error: 0.5815 - val_loss: 0.4921 - val_mean_absolute_error: 0.5425
    Epoch 156/250
    32/32 [==============================] - 0s 125us/step - loss: 0.6594 - mean_absolute_error: 0.5808 - val_loss: 0.4916 - val_mean_absolute_error: 0.5421
    Epoch 157/250
    32/32 [==============================] - 0s 125us/step - loss: 0.6578 - mean_absolute_error: 0.5800 - val_loss: 0.4910 - val_mean_absolute_error: 0.5417
    Epoch 158/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6563 - mean_absolute_error: 0.5792 - val_loss: 0.4905 - val_mean_absolute_error: 0.5413
    Epoch 159/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6548 - mean_absolute_error: 0.5785 - val_loss: 0.4899 - val_mean_absolute_error: 0.5410
    Epoch 160/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6533 - mean_absolute_error: 0.5777 - val_loss: 0.4894 - val_mean_absolute_error: 0.5406
    Epoch 161/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6519 - mean_absolute_error: 0.5770 - val_loss: 0.4889 - val_mean_absolute_error: 0.5403
    Epoch 162/250
    32/32 [==============================] - 0s 125us/step - loss: 0.6504 - mean_absolute_error: 0.5763 - val_loss: 0.4884 - val_mean_absolute_error: 0.5399
    Epoch 163/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6490 - mean_absolute_error: 0.5756 - val_loss: 0.4879 - val_mean_absolute_error: 0.5396
    Epoch 164/250
    32/32 [==============================] - 0s 125us/step - loss: 0.6475 - mean_absolute_error: 0.5749 - val_loss: 0.4875 - val_mean_absolute_error: 0.5393
    Epoch 165/250
    32/32 [==============================] - 0s 125us/step - loss: 0.6461 - mean_absolute_error: 0.5742 - val_loss: 0.4870 - val_mean_absolute_error: 0.5390
    Epoch 166/250
    32/32 [==============================] - 0s 62us/step - loss: 0.6447 - mean_absolute_error: 0.5735 - val_loss: 0.4865 - val_mean_absolute_error: 0.5387
    Epoch 167/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6433 - mean_absolute_error: 0.5728 - val_loss: 0.4861 - val_mean_absolute_error: 0.5384
    Epoch 168/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6419 - mean_absolute_error: 0.5722 - val_loss: 0.4857 - val_mean_absolute_error: 0.5381
    Epoch 169/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6406 - mean_absolute_error: 0.5715 - val_loss: 0.4852 - val_mean_absolute_error: 0.5379
    Epoch 170/250
    32/32 [==============================] - 0s 124us/step - loss: 0.6392 - mean_absolute_error: 0.5709 - val_loss: 0.4848 - val_mean_absolute_error: 0.5376
    Epoch 171/250
    32/32 [==============================] - 0s 125us/step - loss: 0.6378 - mean_absolute_error: 0.5702 - val_loss: 0.4844 - val_mean_absolute_error: 0.5373
    Epoch 172/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6365 - mean_absolute_error: 0.5696 - val_loss: 0.4839 - val_mean_absolute_error: 0.5370
    Epoch 173/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6352 - mean_absolute_error: 0.5690 - val_loss: 0.4835 - val_mean_absolute_error: 0.5367
    Epoch 174/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6338 - mean_absolute_error: 0.5683 - val_loss: 0.4831 - val_mean_absolute_error: 0.5364
    Epoch 175/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6325 - mean_absolute_error: 0.5677 - val_loss: 0.4828 - val_mean_absolute_error: 0.5362
    Epoch 176/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6313 - mean_absolute_error: 0.5671 - val_loss: 0.4824 - val_mean_absolute_error: 0.5360
    Epoch 177/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6300 - mean_absolute_error: 0.5665 - val_loss: 0.4820 - val_mean_absolute_error: 0.5357
    Epoch 178/250
    32/32 [==============================] - 0s 62us/step - loss: 0.6287 - mean_absolute_error: 0.5658 - val_loss: 0.4816 - val_mean_absolute_error: 0.5355
    Epoch 179/250
    32/32 [==============================] - 0s 124us/step - loss: 0.6274 - mean_absolute_error: 0.5652 - val_loss: 0.4811 - val_mean_absolute_error: 0.5352
    Epoch 180/250
    32/32 [==============================] - 0s 95us/step - loss: 0.6262 - mean_absolute_error: 0.5646 - val_loss: 0.4807 - val_mean_absolute_error: 0.5349
    Epoch 181/250
    32/32 [==============================] - 0s 125us/step - loss: 0.6249 - mean_absolute_error: 0.5640 - val_loss: 0.4802 - val_mean_absolute_error: 0.5347
    Epoch 182/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6237 - mean_absolute_error: 0.5634 - val_loss: 0.4798 - val_mean_absolute_error: 0.5345
    Epoch 183/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6225 - mean_absolute_error: 0.5627 - val_loss: 0.4794 - val_mean_absolute_error: 0.5343
    Epoch 184/250
    32/32 [==============================] - 0s 125us/step - loss: 0.6212 - mean_absolute_error: 0.5621 - val_loss: 0.4790 - val_mean_absolute_error: 0.5340
    Epoch 185/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6200 - mean_absolute_error: 0.5615 - val_loss: 0.4785 - val_mean_absolute_error: 0.5338
    Epoch 186/250
    32/32 [==============================] - 0s 62us/step - loss: 0.6188 - mean_absolute_error: 0.5609 - val_loss: 0.4781 - val_mean_absolute_error: 0.5336
    Epoch 187/250
    32/32 [==============================] - 0s 124us/step - loss: 0.6176 - mean_absolute_error: 0.5603 - val_loss: 0.4776 - val_mean_absolute_error: 0.5334
    Epoch 188/250
    32/32 [==============================] - 0s 63us/step - loss: 0.6164 - mean_absolute_error: 0.5597 - val_loss: 0.4772 - val_mean_absolute_error: 0.5331
    Epoch 189/250
    32/32 [==============================] - 0s 125us/step - loss: 0.6152 - mean_absolute_error: 0.5591 - val_loss: 0.4767 - val_mean_absolute_error: 0.5329
    Epoch 190/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6140 - mean_absolute_error: 0.5585 - val_loss: 0.4763 - val_mean_absolute_error: 0.5327
    Epoch 191/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6129 - mean_absolute_error: 0.5580 - val_loss: 0.4759 - val_mean_absolute_error: 0.5325
    Epoch 192/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6117 - mean_absolute_error: 0.5574 - val_loss: 0.4756 - val_mean_absolute_error: 0.5323
    Epoch 193/250
    32/32 [==============================] - 0s 62us/step - loss: 0.6106 - mean_absolute_error: 0.5568 - val_loss: 0.4752 - val_mean_absolute_error: 0.5321
    Epoch 194/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6094 - mean_absolute_error: 0.5562 - val_loss: 0.4748 - val_mean_absolute_error: 0.5319
    Epoch 195/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6083 - mean_absolute_error: 0.5556 - val_loss: 0.4743 - val_mean_absolute_error: 0.5317
    Epoch 196/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6071 - mean_absolute_error: 0.5550 - val_loss: 0.4739 - val_mean_absolute_error: 0.5315
    Epoch 197/250
    32/32 [==============================] - 0s 93us/step - loss: 0.6060 - mean_absolute_error: 0.5545 - val_loss: 0.4734 - val_mean_absolute_error: 0.5312
    Epoch 198/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6049 - mean_absolute_error: 0.5539 - val_loss: 0.4730 - val_mean_absolute_error: 0.5310
    Epoch 199/250
    32/32 [==============================] - 0s 125us/step - loss: 0.6038 - mean_absolute_error: 0.5533 - val_loss: 0.4725 - val_mean_absolute_error: 0.5308
    Epoch 200/250
    32/32 [==============================] - 0s 124us/step - loss: 0.6027 - mean_absolute_error: 0.5528 - val_loss: 0.4721 - val_mean_absolute_error: 0.5306
    Epoch 201/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6016 - mean_absolute_error: 0.5523 - val_loss: 0.4717 - val_mean_absolute_error: 0.5303
    Epoch 202/250
    32/32 [==============================] - 0s 94us/step - loss: 0.6005 - mean_absolute_error: 0.5517 - val_loss: 0.4713 - val_mean_absolute_error: 0.5301
    Epoch 203/250
    32/32 [==============================] - 0s 93us/step - loss: 0.5994 - mean_absolute_error: 0.5511 - val_loss: 0.4709 - val_mean_absolute_error: 0.5299
    Epoch 204/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5982 - mean_absolute_error: 0.5505 - val_loss: 0.4704 - val_mean_absolute_error: 0.5296
    Epoch 205/250
    32/32 [==============================] - 0s 125us/step - loss: 0.5971 - mean_absolute_error: 0.5500 - val_loss: 0.4700 - val_mean_absolute_error: 0.5294
    Epoch 206/250
    32/32 [==============================] - 0s 93us/step - loss: 0.5960 - mean_absolute_error: 0.5494 - val_loss: 0.4696 - val_mean_absolute_error: 0.5292
    Epoch 207/250
    32/32 [==============================] - 0s 124us/step - loss: 0.5949 - mean_absolute_error: 0.5488 - val_loss: 0.4692 - val_mean_absolute_error: 0.5289
    Epoch 208/250
    32/32 [==============================] - 0s 93us/step - loss: 0.5938 - mean_absolute_error: 0.5483 - val_loss: 0.4689 - val_mean_absolute_error: 0.5287
    Epoch 209/250
    32/32 [==============================] - 0s 125us/step - loss: 0.5927 - mean_absolute_error: 0.5477 - val_loss: 0.4685 - val_mean_absolute_error: 0.5285
    Epoch 210/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5916 - mean_absolute_error: 0.5471 - val_loss: 0.4681 - val_mean_absolute_error: 0.5283
    Epoch 211/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5904 - mean_absolute_error: 0.5464 - val_loss: 0.4678 - val_mean_absolute_error: 0.5280
    Epoch 212/250
    32/32 [==============================] - 0s 125us/step - loss: 0.5892 - mean_absolute_error: 0.5459 - val_loss: 0.4674 - val_mean_absolute_error: 0.5278
    Epoch 213/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5880 - mean_absolute_error: 0.5453 - val_loss: 0.4670 - val_mean_absolute_error: 0.5275
    Epoch 214/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5868 - mean_absolute_error: 0.5447 - val_loss: 0.4667 - val_mean_absolute_error: 0.5273
    Epoch 215/250
    32/32 [==============================] - 0s 93us/step - loss: 0.5856 - mean_absolute_error: 0.5441 - val_loss: 0.4663 - val_mean_absolute_error: 0.5270
    Epoch 216/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5845 - mean_absolute_error: 0.5436 - val_loss: 0.4660 - val_mean_absolute_error: 0.5268
    Epoch 217/250
    32/32 [==============================] - 0s 93us/step - loss: 0.5834 - mean_absolute_error: 0.5430 - val_loss: 0.4657 - val_mean_absolute_error: 0.5266
    Epoch 218/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5823 - mean_absolute_error: 0.5425 - val_loss: 0.4653 - val_mean_absolute_error: 0.5263
    Epoch 219/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5812 - mean_absolute_error: 0.5419 - val_loss: 0.4649 - val_mean_absolute_error: 0.5260
    Epoch 220/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5802 - mean_absolute_error: 0.5414 - val_loss: 0.4645 - val_mean_absolute_error: 0.5257
    Epoch 221/250
    32/32 [==============================] - 0s 125us/step - loss: 0.5791 - mean_absolute_error: 0.5408 - val_loss: 0.4641 - val_mean_absolute_error: 0.5254
    Epoch 222/250
    32/32 [==============================] - 0s 93us/step - loss: 0.5780 - mean_absolute_error: 0.5403 - val_loss: 0.4637 - val_mean_absolute_error: 0.5251
    Epoch 223/250
    32/32 [==============================] - 0s 93us/step - loss: 0.5770 - mean_absolute_error: 0.5397 - val_loss: 0.4634 - val_mean_absolute_error: 0.5248
    Epoch 224/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5760 - mean_absolute_error: 0.5392 - val_loss: 0.4630 - val_mean_absolute_error: 0.5245
    Epoch 225/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5750 - mean_absolute_error: 0.5387 - val_loss: 0.4627 - val_mean_absolute_error: 0.5243
    Epoch 226/250
    32/32 [==============================] - 0s 93us/step - loss: 0.5740 - mean_absolute_error: 0.5382 - val_loss: 0.4624 - val_mean_absolute_error: 0.5240
    Epoch 227/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5730 - mean_absolute_error: 0.5377 - val_loss: 0.4622 - val_mean_absolute_error: 0.5239
    Epoch 228/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5720 - mean_absolute_error: 0.5372 - val_loss: 0.4621 - val_mean_absolute_error: 0.5237
    Epoch 229/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5711 - mean_absolute_error: 0.5366 - val_loss: 0.4619 - val_mean_absolute_error: 0.5236
    Epoch 230/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5701 - mean_absolute_error: 0.5361 - val_loss: 0.4617 - val_mean_absolute_error: 0.5234
    Epoch 231/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5692 - mean_absolute_error: 0.5356 - val_loss: 0.4614 - val_mean_absolute_error: 0.5233
    Epoch 232/250
    32/32 [==============================] - 0s 125us/step - loss: 0.5682 - mean_absolute_error: 0.5351 - val_loss: 0.4611 - val_mean_absolute_error: 0.5231
    Epoch 233/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5672 - mean_absolute_error: 0.5346 - val_loss: 0.4608 - val_mean_absolute_error: 0.5229
    Epoch 234/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5663 - mean_absolute_error: 0.5340 - val_loss: 0.4605 - val_mean_absolute_error: 0.5226
    Epoch 235/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5653 - mean_absolute_error: 0.5335 - val_loss: 0.4601 - val_mean_absolute_error: 0.5224
    Epoch 236/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5643 - mean_absolute_error: 0.5330 - val_loss: 0.4597 - val_mean_absolute_error: 0.5221
    Epoch 237/250
    32/32 [==============================] - 0s 93us/step - loss: 0.5634 - mean_absolute_error: 0.5324 - val_loss: 0.4593 - val_mean_absolute_error: 0.5218
    Epoch 238/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5624 - mean_absolute_error: 0.5319 - val_loss: 0.4589 - val_mean_absolute_error: 0.5215
    Epoch 239/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5615 - mean_absolute_error: 0.5314 - val_loss: 0.4586 - val_mean_absolute_error: 0.5213
    Epoch 240/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5606 - mean_absolute_error: 0.5308 - val_loss: 0.4582 - val_mean_absolute_error: 0.5210
    Epoch 241/250
    32/32 [==============================] - 0s 93us/step - loss: 0.5597 - mean_absolute_error: 0.5303 - val_loss: 0.4579 - val_mean_absolute_error: 0.5208
    Epoch 242/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5588 - mean_absolute_error: 0.5297 - val_loss: 0.4576 - val_mean_absolute_error: 0.5206
    Epoch 243/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5579 - mean_absolute_error: 0.5292 - val_loss: 0.4573 - val_mean_absolute_error: 0.5203
    Epoch 244/250
    32/32 [==============================] - 0s 93us/step - loss: 0.5570 - mean_absolute_error: 0.5286 - val_loss: 0.4570 - val_mean_absolute_error: 0.5200
    Epoch 245/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5561 - mean_absolute_error: 0.5281 - val_loss: 0.4567 - val_mean_absolute_error: 0.5198
    Epoch 246/250
    32/32 [==============================] - 0s 93us/step - loss: 0.5552 - mean_absolute_error: 0.5276 - val_loss: 0.4564 - val_mean_absolute_error: 0.5196
    Epoch 247/250
    32/32 [==============================] - 0s 93us/step - loss: 0.5543 - mean_absolute_error: 0.5270 - val_loss: 0.4561 - val_mean_absolute_error: 0.5195
    Epoch 248/250
    32/32 [==============================] - 0s 93us/step - loss: 0.5534 - mean_absolute_error: 0.5265 - val_loss: 0.4558 - val_mean_absolute_error: 0.5193
    Epoch 249/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5526 - mean_absolute_error: 0.5260 - val_loss: 0.4555 - val_mean_absolute_error: 0.5190
    Epoch 250/250
    32/32 [==============================] - 0s 94us/step - loss: 0.5517 - mean_absolute_error: 0.5255 - val_loss: 0.4552 - val_mean_absolute_error: 0.5188
    


![png](output_3_2.png)



```python
# 讀取模型
autoencoder = load_model('hermit_model')

# 利用訓練好的autoencoder重建測試集
pred_test = autoencoder.predict(X_test)
pred_fraud = autoencoder.predict(X_fraud)

# 計算還原誤差MSE和MAE
markers = ['o', '^']
markers = ['o', '^']
colors = ['dodgerblue', 'coral']
labels = ['Negative', 'Positive']

plt.figure(figsize=(14, 5))
plt.subplot(121)
for flag in [1, 0]:
    temp = mse_df[mse_df['targets_names'] == flag]
    plt.scatter(temp.index, 
                temp['MAE'],  
                alpha=0.7, 
                marker=markers[flag], 
                c=colors[flag], 
                label=labels[flag])
plt.title('Reconstruction MAE')
plt.ylabel('Reconstruction MAE'); plt.xlabel('Index')
threshold = mse_df['MAE'].min()+0.8*mse_df['MAE'].std()
plt.plot([0,len(y)],[threshold,threshold])
plt.subplot(122)

for flag in [1, 0]:
    temp = mse_df[mse_df['targets_names'] == flag]
    plt.scatter(temp.index, 
                temp['MSE'],  
                alpha=0.7, 
                marker=markers[flag], 
                c=colors[flag], 
                label=labels[flag])
plt.legend(loc=[1, 0], fontsize=12); plt.title('Reconstruction MSE')
threshold = mse_df['MSE'].min()+mse_df['MSE'].std()
plt.plot([0,len(y)],[threshold,threshold])
plt.ylabel('Reconstruction MSE'); plt.xlabel('Index')
plt.show()
```


![png](output_4_0.png)


# Results for mse


```python
#用MSE的threshold的結果分類，計算auc以及acc等統計量值
from sklearn import metrics

threshold = mse_df['MSE'].min()+mse_df['MSE'].std()
mse_df['targets_names']
mse_df['mse_y_pred'] = [1 if e > threshold else 0 for e in mse_df['MSE']]
mse_df['targets_names'].describe()
test_auc = metrics.roc_auc_score(mse_df['targets_names'], mse_df['mse_y_pred'])
print (test_auc)
```

    0.693939393939394
    


```python
#用MAE的threshold的結果分類，計算auc以及acc等統計量值
from sklearn import metrics

threshold = mse_df['MAE'].min()+0.8*mse_df['MAE'].std()
mse_df['targets_names']
mse_df['mae_y_pred'] = [1 if e > threshold else 0 for e in mse_df['MAE']]
mse_df['targets_names'].describe()
test_auc = metrics.roc_auc_score(mse_df['targets_names'], mse_df['mae_y_pred'])
print (test_auc)
```

    0.548051948051948
    


```python
from sklearn.metrics import confusion_matrix
LABELS = ["Negative", "Positive"]
conf_matrix = confusion_matrix(mse_df['targets_names'], mse_df['mse_y_pred'])
plt.figure(figsize=(12, 12))
sns.heatmap(conf_matrix, xticklabels=LABELS, yticklabels=LABELS, annot=True, fmt="d");
plt.title("Confusion matrix")
plt.ylabel('True class')
plt.xlabel('Predicted class')
plt.show()
```


![png](output_8_0.png)



```python
from sklearn.metrics import confusion_matrix
LABELS = ["Negative", "Positive"]
conf_matrix = confusion_matrix(mse_df['targets_names'], mse_df['mae_y_pred'])
plt.figure(figsize=(12, 12))
sns.heatmap(conf_matrix, xticklabels=LABELS, yticklabels=LABELS, annot=True, fmt="d");
plt.title("Confusion matrix")
plt.ylabel('True class')
plt.xlabel('Predicted class')
plt.show()
```


![png](output_9_0.png)



```python
# 畫出Precision-Recall曲線
plt.figure(figsize=(14, 6))
for i, metric in enumerate(['MAE', 'MSE']):
    plt.subplot(1, 2, i+1)
    precision, recall, _ = precision_recall_curve(mse_df['targets_names'], mse_df[metric])
    pr_auc = auc(recall, precision)
    plt.title('Precision-Recall curve based on %s\nAUC = %0.2f'%(metric, pr_auc))
    plt.plot(recall[:-2], precision[:-2], c='coral', lw=4)
    plt.xlabel('Recall'); plt.ylabel('Precision')
plt.show()

# 畫出ROC曲線
plt.figure(figsize=(14, 6))
for i, metric in enumerate(['MAE', 'MSE']):
    plt.subplot(1, 2, i+1)
    fpr, tpr, _ = roc_curve(mse_df['targets_names'], mse_df[metric])
    roc_auc = auc(fpr, tpr)
    plt.title('Receiver Operating Characteristic based on %s\nAUC = %0.2f'%(metric, roc_auc))
    plt.plot(fpr, tpr, c='coral', lw=4)
    plt.plot([0,1],[0,1], c='dodgerblue', ls='--')
    plt.ylabel('TPR'); plt.xlabel('FPR')
plt.show()

```


![png](output_10_0.png)



![png](output_10_1.png)



```python
#用MSE&MAE的threshold的結果分類，計算auc以及acc等統計量值
from sklearn import metrics

mse_threshold = mse_df['MSE'].min()+mse_df['MSE'].std()
mae_threshold = mse_df['MAE'].min()+0.8*mse_df['MAE'].std()
mse_df['msae_y_pred'] = 0
for i in range(len(mse_df['mse_y_pred'])):
    if mse_df['mse_y_pred'][i] == mse_df['mae_y_pred'][i]:
        mse_df['msae_y_pred'][i] = 1
mse_df['targets_names'].describe()
test_auc = metrics.roc_auc_score(mse_df['targets_names'], mse_df['msae_y_pred'])
print (test_auc)
```

    0.645887445887446
    

    C:\Users\User\Anaconda3\envs\Tensorflow-gpu\lib\site-packages\ipykernel_launcher.py:9: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      if __name__ == '__main__':
    


```python
mse_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>targets_names</th>
      <th>MSE</th>
      <th>MAE</th>
      <th>y_pred</th>
      <th>mse_y_pred</th>
      <th>mae_y_pred</th>
      <th>msae_y_pred</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>1.303796</td>
      <td>1.009276</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0.651611</td>
      <td>0.642855</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>0.732258</td>
      <td>0.836285</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>0.440141</td>
      <td>0.563211</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>0.502424</td>
      <td>0.569734</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 畫出MSE、MAE散點圖
markers = ['o', '^']
colors = ['dodgerblue', 'coral']
labels = ['Negative', 'Positive']

plt.figure(figsize=(10, 5))
for flag in [1, 0]:
    temp = mse_df[mse_df['targets_names'] == flag]
    plt.scatter(temp['MAE'], 
                temp['MSE'],  
                alpha=0.7, 
                marker=markers[flag], 
                c=colors[flag], 
                label=labels[flag])
plt.legend(loc=[1, 0])
plt.plot([mse_threshold,mse_threshold],[0,mse_df['MSE'].max()])
plt.plot([0,mse_df['MAE'].max()],[mae_threshold,mae_threshold])
plt.ylabel('Reconstruction RMSE'); plt.xlabel('Reconstruction MAE')
plt.show()
```


![png](output_13_0.png)



```python
from sklearn.metrics import confusion_matrix
LABELS = ["Negative", "Positive"]
conf_matrix = confusion_matrix(mse_df['targets_names'], mse_df['msae_y_pred'])
plt.figure(figsize=(12, 12))
sns.heatmap(conf_matrix, xticklabels=LABELS, yticklabels=LABELS, annot=True, fmt="d");
plt.title("Confusion matrix")
plt.ylabel('True class')
plt.xlabel('Predicted class')
plt.show()
```


![png](output_14_0.png)


# oc svm rbf compare test


```python
from sklearn import svm

clf = svm.OneClassSVM(kernel='rbf', gamma='auto').fit(X_train)

origin = pd.DataFrame(clf.score_samples(X_train))
origin.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>32.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>3.200010</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.787623</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.584031</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2.982172</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>3.411853</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>3.761056</td>
    </tr>
    <tr>
      <th>max</th>
      <td>4.143283</td>
    </tr>
  </tbody>
</table>
</div>




```python
new = pd.DataFrame(clf.score_samples(X_test))
occ = pd.concat([pd.DataFrame(new[0] < origin[0].min()),pd.DataFrame(new[0] > origin[0].max())], axis=1)
occ['ava'] = pd.DataFrame(occ.iloc[:,1:2] == occ.iloc[:,0:1])
err = sum(occ['ava'] == False)/len(occ['ava'])
err
```




    0.09090909090909091




```python
new = pd.DataFrame(clf.score_samples(X_fraud))
occ = pd.concat([pd.DataFrame(new[0] < origin[0].min()),pd.DataFrame(new[0] > origin[0].max())], axis=1)
occ['ava'] = pd.DataFrame(occ.iloc[:,1:2] == occ.iloc[:,0:1])
err = sum(occ['ava'] == False)/len(occ['ava'])
err
```




    0.34285714285714286




```python
occ
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>0</th>
      <th>ava</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>5</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>6</th>
      <td>False</td>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>7</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>8</th>
      <td>False</td>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>9</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>10</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>11</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>12</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>13</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>14</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>15</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>16</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>17</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>19</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>20</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>21</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>22</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>24</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>25</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>26</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>27</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>28</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>29</th>
      <td>False</td>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>30</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>31</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>32</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>33</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>34</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>


